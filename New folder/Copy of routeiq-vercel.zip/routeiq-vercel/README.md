# Route IQ

AI-powered field sales routing app for Oklahoma reps.

## Deploy to Vercel

### Option A — Vercel CLI (fastest)
```bash
npm i -g vercel
vercel --prod
```

### Option B — GitHub + Vercel Dashboard
1. Push this folder to a GitHub repo
2. Go to vercel.com → New Project → Import repo
3. Framework: Other (static)
4. Root Directory: ./
5. Click Deploy

### Option C — Drag & Drop
Go to vercel.com/new and drag this entire folder.

## PWA Install
After deploying, open the live URL in Safari on iPhone:
Share → Add to Home Screen → Route IQ

## Anthropic API Key
Go to Intelligence tab → paste your sk-ant-... key → Save Key
The key is stored locally in your browser only.
